import random
import json

class ParkingLot:
    def __init__(self, square_footage, spot_length=8, spot_width=12):
        self.spot_size = spot_length * spot_width
        self.total_spots = square_footage // self.spot_size
        self.parking_spots = [None] * self.total_spots

    def park_car(self, car, spot_number):
        if self.parking_spots[spot_number] is None:
            self.parking_spots[spot_number] = car
            return True
        else:
            return False

    def is_full(self):
        return all(self.parking_spots)

    def map_vehicles_to_spots(self):
        mapping = {f"Spot {i}": str(car) if car else None for i, car in enumerate(self.parking_spots)}
        return mapping

    def save_mapping_to_file(self, filename):
        mapping = self.map_vehicles_to_spots()
        with open(filename, 'w') as file:
            json.dump(mapping, file, indent=4)

class Car:
    def __init__(self, license_plate):
        if len(license_plate) != 7 or not license_plate.isdigit():
            raise ValueError("License plate must be a 7-digit number")
        self.license_plate = license_plate

    def __str__(self):
        return self.license_plate

    def park(self, parking_lot):
        while True:
            spot_number = random.randint(0, parking_lot.total_spots - 1)
            if parking_lot.park_car(self, spot_number):
                print(f"Car with license plate {self} parked successfully in spot {spot_number}.")
                break
            else:
                print(f"Spot {spot_number} is occupied. Trying another spot...")

def main():
    square_footage = 2000
    cars = [Car(str(random.randint(1000000, 9999999))) for _ in range(25)]  # Creating 25 cars with random 7-digit license plates
    parking_lot = ParkingLot(square_footage)

    for car in cars:
        if parking_lot.is_full():
            print("Parking lot is full. Exiting the program.")
            break
        car.park(parking_lot)

    # Bonus: Save the mapping to a file
    parking_lot.save_mapping_to_file("parking_lot_mapping.json")

if __name__ == "__main__":
    main()
